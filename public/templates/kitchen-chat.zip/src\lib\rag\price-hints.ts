import type { MenuMatch } from "@/lib/rag/menu-rag";

const PRICE_PATTERN =
  /(?:cost\s*)?(?:rs\.?|inr|₹)\s*\d+(?:\.\d{1,2})?(?:\s*\/\s*[a-z0-9 ]+)?|\d+(?:\.\d{1,2})?\s*(?:rs\.?|inr|₹)(?:\s*\/\s*[a-z0-9 ]+)?/gi;

export function addPriceHints(match: MenuMatch): MenuMatch {
  const hints = extractPriceHints(match.content);

  return {
    ...match,
    priceHints: hints
  };
}

export function formatPriceHints(matches: MenuMatch[]) {
  return matches
    .filter((match) => match.priceHints && match.priceHints.length > 0)
    .map((match) => `${match.title}: ${match.priceHints?.join(", ")}`)
    .join("\n");
}

function extractPriceHints(content: string) {
  const prices = content.match(PRICE_PATTERN) ?? [];
  const uniquePrices = [...new Set(prices.map((price) => price.replace(/\s+/g, " ").trim()))];

  return uniquePrices.slice(0, 6);
}
