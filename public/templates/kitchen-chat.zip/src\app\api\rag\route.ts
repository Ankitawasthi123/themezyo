import { NextResponse } from "next/server";
import { generateKitchenAnswer } from "@/lib/llm/gemini";
import { addPriceHints } from "@/lib/rag/price-hints";
import { searchMenus, splitMenuDocuments } from "@/lib/rag/menu-rag";
import { findUploadedPriceChunks, searchUploadedMenuChunks } from "@/lib/vector/chroma";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { query?: string; userProfile?: string } | null;
  const query = body?.query?.trim();
  const userProfile = body?.userProfile?.trim();

  if (!query) {
    return NextResponse.json({ error: "Query is required." }, { status: 400 });
  }

  const wantsPrice = /\b(price|cost|rate|rs|inr|₹)\b/i.test(query);
  const wantsRecipe = /\b(recipe|cook|make|prepare|share)\b/i.test(query);
  const shouldFetchPriceHints = wantsPrice || wantsRecipe;
  const [demoMatches, uploadedMatches, priceMatches, chunks] = await Promise.all([
    searchMenus(query).then((matches) => matches.map(addPriceHints)),
    searchUploadedMenuChunks(query, wantsPrice ? 12 : 6).catch(() => []),
    shouldFetchPriceHints ? findUploadedPriceChunks(wantsPrice ? 8 : 4).catch(() => []) : Promise.resolve([]),
    splitMenuDocuments()
  ]);
  const uniqueMatches = new Map([...priceMatches, ...uploadedMatches, ...demoMatches].map((match) => [match.id, match]));
  const matches = [...uniqueMatches.values()]
    .sort((first, second) => {
      if (wantsRecipe && !wantsPrice) {
        return getRecipePriority(second, query) - getRecipePriority(first, query) || second.score - first.score;
      }

      if (!wantsPrice) {
        return second.score - first.score;
      }

      const firstHasPrice = first.priceHints && first.priceHints.length > 0 ? 1 : 0;
      const secondHasPrice = second.priceHints && second.priceHints.length > 0 ? 1 : 0;

      return secondHasPrice - firstHasPrice || second.score - first.score;
    })
    .slice(0, wantsPrice ? 8 : 6);
  const completion = await generateKitchenAnswer({
    query,
    userProfile,
    matches
  });
  const responsePayload = {
    query,
    answer: completion.answer,
    provider: completion.provider,
    model: completion.model,
    matches,
    chunkCount: chunks.length
  };

  console.log(
    "[api/rag] response",
    JSON.stringify(
      {
        query: responsePayload.query,
        provider: responsePayload.provider,
        model: responsePayload.model,
        answer: responsePayload.answer,
        matches: responsePayload.matches.map((match) => ({
          id: match.id,
          title: match.title,
          score: match.score,
          source: match.source ?? "unknown",
          priceHints: match.priceHints ?? [],
          contentPreview: match.content.slice(0, 240)
        })),
        chunkCount: responsePayload.chunkCount
      },
      null,
      2
    )
  );

  return NextResponse.json(responsePayload);
}

function getRecipePriority(match: { id: string; title: string; content: string }, query: string) {
  const text = `${match.id} ${match.title} ${match.content}`.toLowerCase();
  const queryWords = getImportantWords(query);
  const hits = queryWords.filter((word) => text.includes(word)).length;
  let priority = 0;

  priority += hits * 10;

  if (text.includes(".pdf") || text.includes("uploaded pdf")) {
    priority += 4;
  }

  if (text.includes("method of preparation")) {
    priority += 3;
  }

  if (text.includes("ingredients")) {
    priority += 2;
  }

  return priority;
}

function getImportantWords(query: string) {
  const stopWords = new Set(["i", "have", "the", "a", "an", "and", "with", "share", "recipe", "provide", "for", "me"]);

  return query
    .toLowerCase()
    .split(/\W+/)
    .map((word) => {
      if (word === "ege") {
        return "egg";
      }

      if (word === "maggie" || word === "magie") {
        return "maggi";
      }

      return word;
    })
    .filter((word) => word.length > 2 && !stopWords.has(word));
}
