"use client";

import {
  ChefHat,
  Database,
  Loader2,
  MessageSquareText,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  Upload,
  UserRound
} from "lucide-react";
import { ChangeEvent, FormEvent, useState } from "react";

type Message = {
  id: number;
  role: "user" | "assistant";
  content: string;
};

type MenuMatch = {
  id: string;
  title: string;
  content: string;
  score: number;
  priceHints?: string[];
  source?: "demo" | "uploaded-pdf";
};

type RagResponse = {
  answer?: string;
  error?: string;
  matches?: MenuMatch[];
  model?: string;
  provider?: string;
};

type RecipeAnswer = {
  item: string;
  price: string;
  prepTime?: string;
  cookTime?: string;
  servings?: string;
  ingredients: string[];
  method: string[];
  servingSuggestion?: string;
  notes?: string;
};

function FormattedMessage({ content }: { content: string }) {
  const recipe = parseRecipeAnswer(content);

  if (recipe) {
    return <RecipeMessage recipe={recipe} />;
  }

  const parts = content.split(/(\*\*[^*]+\*\*)/g);

  return (
    <p>
      {parts.map((part, index) => {
        if (part.startsWith("**") && part.endsWith("**")) {
          return <strong key={`${part}-${index}`}>{part.slice(2, -2)}</strong>;
        }

        return <span key={`${part}-${index}`}>{part}</span>;
      })}
    </p>
  );
}

function RecipeMessage({ recipe }: { recipe: RecipeAnswer }) {
  return (
    <div className="recipe-answer">
      <div className="recipe-heading">
        <span>Recipe</span>
        <h3>{recipe.item}</h3>
      </div>

      <table className="recipe-summary">
        <tbody>
          <tr>
            <th scope="row">Price</th>
            <td>{recipe.price}</td>
          </tr>
          <tr>
            <th scope="row">Ingredients</th>
            <td>{recipe.ingredients.length} items</td>
          </tr>
          {recipe.prepTime ? (
            <tr>
              <th scope="row">Prep time</th>
              <td>{recipe.prepTime}</td>
            </tr>
          ) : null}
          {recipe.cookTime ? (
            <tr>
              <th scope="row">Cook time</th>
              <td>{recipe.cookTime}</td>
            </tr>
          ) : null}
          {recipe.servings ? (
            <tr>
              <th scope="row">Servings</th>
              <td>{recipe.servings}</td>
            </tr>
          ) : null}
        </tbody>
      </table>

      <div className="recipe-section">
        <h4>Ingredients</h4>
        <ul className="ingredient-list">
          {recipe.ingredients.map((ingredient) => (
            <li key={ingredient}>{ingredient}</li>
          ))}
        </ul>
      </div>

      <div className="recipe-section">
        <h4>Method</h4>
        <ol className="method-list">
          {recipe.method.map((step) => (
            <li key={step}>{step}</li>
          ))}
        </ol>
      </div>

      {recipe.servingSuggestion || recipe.notes ? (
        <div className="recipe-notes">
          {recipe.servingSuggestion ? (
            <p>
              <strong>Serve with:</strong> {recipe.servingSuggestion}
            </p>
          ) : null}
          {recipe.notes ? (
            <p>
              <strong>Notes:</strong> {recipe.notes}
            </p>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

function parseRecipeAnswer(content: string): RecipeAnswer | null {
  const cleaned = content.replace(/\*\*/g, "").trim();
  const item = getAnswerField(cleaned, "Item", ["Price", "Ingredients", "Method"]);
  const price = getAnswerField(cleaned, "Price", ["Prep time", "Cook time", "Servings", "Ingredients", "Method"]);
  const prepTime = getAnswerField(cleaned, "Prep time", ["Cook time", "Servings", "Ingredients", "Method"]);
  const cookTime = getAnswerField(cleaned, "Cook time", ["Servings", "Ingredients", "Method"]);
  const servings = getAnswerField(cleaned, "Servings", ["Ingredients", "Method"]);
  const ingredients = getAnswerField(cleaned, "Ingredients", ["Method"]);
  const method = getAnswerField(cleaned, "Method", ["Serving suggestion", "Notes"]);
  const servingSuggestion = getAnswerField(cleaned, "Serving suggestion", ["Notes"]);
  const notes = getAnswerField(cleaned, "Notes", []);

  if (!item || !ingredients || !method) {
    return null;
  }

  return {
    item,
    price: price || "Price not found in uploaded menu",
    prepTime,
    cookTime,
    servings,
    ingredients: splitIngredients(ingredients),
    method: splitMethod(method),
    servingSuggestion,
    notes
  };
}

function getAnswerField(content: string, label: string, nextLabels: string[]) {
  const startPattern = new RegExp(`(?:^|\\|)\\s*${label}\\s*:`, "i");
  const startMatch = content.match(startPattern);

  if (!startMatch || startMatch.index === undefined) {
    return "";
  }

  const start = startMatch.index + startMatch[0].length;
  const rest = content.slice(start);
  const nextIndexes = nextLabels
    .map((nextLabel) => {
      const nextMatch = rest.match(new RegExp(`\\|\\s*${nextLabel}\\s*:`, "i"));

      return nextMatch?.index ?? -1;
    })
    .filter((index) => index >= 0);
  const end = nextIndexes.length > 0 ? Math.min(...nextIndexes) : rest.length;

  return normalizeRecipeText(rest.slice(0, end).replace(/\|+$/, ""));
}

function splitIngredients(value: string) {
  return value
    .split(/\s*,\s*/)
    .map(normalizeRecipeText)
    .filter(Boolean);
}

function splitMethod(value: string) {
  const numberedSteps = value
    .split(/\s*\d+\.\s*/)
    .map(normalizeRecipeText)
    .filter(Boolean);

  if (numberedSteps.length > 1) {
    return numberedSteps;
  }

  return value
    .split(/\s*;\s*/)
    .map(normalizeRecipeText)
    .filter(Boolean);
}

function normalizeRecipeText(value: string) {
  return value.replace(/\s+/g, " ").trim();
}

function isGreetingMessage(value: string) {
  return /^(hi|hello|hey|hii|helo|namaste|good morning|good afternoon|good evening)[!. ]*$/i.test(value.trim());
}

function buildGreeting(name: string) {
  const displayName = name.trim() || "there";

  return `Hello ${displayName}. Tell me what ingredients you have, or ask for a recipe from your uploaded menu.`;
}

const authChoices = [
  "Auth.js / NextAuth for self-hosted email login",
  "Firebase Auth for fast free Google/email login",
  "Clerk for polished UI and easy setup",
  "Supabase Auth if you later use Supabase pgvector"
];

const promptIdeas = [
  "I have potato, onion, capsicum. Share a recipe.",
  "Show recipes with price.",
  "Find a low spice vegetarian dinner."
];

export default function Home() {
  const [name, setName] = useState("Jhone doe");
  const [profile, setProfile] = useState("Vegetarian, low spice, budget friendly");
  const [input, setInput] = useState("");
  const [matchedMenus, setMatchedMenus] = useState<MenuMatch[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState("Upload a PDF menu to add it to ChromaDB.");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: "assistant",
      content: "Tell me what you have in the kitchen and I will suggest a personalized menu."
    }
  ]);

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const question = input.trim();

    if (!question || isSending) {
      return;
    }

    const userMessage: Message = { id: Date.now(), role: "user", content: question };
    setMessages((current) => [...current, userMessage]);
    setInput("");

    if (isGreetingMessage(question)) {
      setMatchedMenus([]);
      setMessages((current) => [
        ...current,
        {
          id: Date.now() + 1,
          role: "assistant",
          content: buildGreeting(name)
        }
      ]);

      return;
    }

    setIsSending(true);

    try {
      const response = await fetch("/api/rag", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          query: question,
          userProfile: profile
        })
      });

      const data = (await response.json()) as RagResponse;

      console.log("[Kitchen Chat] /api/rag response", {
        answer: data.answer,
        provider: data.provider,
        model: data.model,
        matches: data.matches?.map((match) => ({
          id: match.id,
          title: match.title,
          score: match.score,
          priceHints: match.priceHints ?? [],
          contentPreview: match.content.slice(0, 240)
        }))
      });

      if (!response.ok) {
        throw new Error(data.error ?? "RAG request failed.");
      }

      setMatchedMenus(data.matches ?? []);
      setMessages((current) => [
        ...current,
        {
          id: Date.now() + 1,
          role: "assistant",
          content: data.answer ?? "I could not create an answer from the current menu data."
        }
      ]);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Something went wrong.";
      setMessages((current) => [
        ...current,
        {
          id: Date.now() + 1,
          role: "assistant",
          content: `API error: ${message}`
        }
      ]);
    } finally {
      setIsSending(false);
    }
  }

  async function uploadPdf(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file || isUploading) {
      return;
    }

    const formData = new FormData();
    formData.append("file", file);
    setIsUploading(true);
    setUploadStatus(`Uploading ${file.name}...`);

    try {
      const response = await fetch("/api/upload-pdf", {
        method: "POST",
        body: formData
      });
      const data = (await response.json()) as { error?: string; chunksStored?: number; fileName?: string };

      console.log("[Kitchen Chat] /api/upload-pdf response", data);

      if (!response.ok) {
        throw new Error(data.error ?? "PDF upload failed.");
      }

      setUploadStatus(`Stored ${data.chunksStored ?? 0} chunks from ${data.fileName ?? file.name}.`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "PDF upload failed.";
      setUploadStatus(message);
    } finally {
      setIsUploading(false);
    }
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">
            <ChefHat aria-hidden="true" />
          </div>
          <div>
            <span>Kitchen Chat</span>
            <small>Menu RAG assistant</small>
          </div>
        </div>

        <section className="panel profile-panel">
          <div className="section-title">
            <UserRound aria-hidden="true" />
            <h2>User Profile</h2>
          </div>
          <label>
            Name
            <input value={name} onChange={(event) => setName(event.target.value)} />
          </label>
          <label>
            Preferences
            <textarea value={profile} onChange={(event) => setProfile(event.target.value)} />
          </label>
        </section>

        <section className="panel upload-panel">
          <div className="section-title">
            <Database aria-hidden="true" />
            <h2>Knowledge Base</h2>
          </div>
          <p>{uploadStatus}</p>
          <label className="upload-button wide" aria-label="Upload PDF menu">
            {isUploading ? <Loader2 className="spin" aria-hidden="true" /> : <Upload aria-hidden="true" />}
            <span>{isUploading ? "Uploading menu" : "Upload PDF menu"}</span>
            <input accept="application/pdf,.pdf" disabled={isUploading} onChange={uploadPdf} type="file" />
          </label>
        </section>

        <section className="panel">
          <div className="section-title">
            <ShieldCheck aria-hidden="true" />
            <h2>Auth Options</h2>
          </div>
          <ul className="compact-list">
            {authChoices.map((choice) => (
              <li key={choice}>{choice}</li>
            ))}
          </ul>
        </section>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div>
            <p className="eyebrow">Local MVP · ChromaDB · Groq</p>
            <h1>Personalized Kitchen Assistant</h1>
            <p className="subtitle">Ask with ingredients, budget, taste, or uploaded menu prices.</p>
          </div>
          <div className="status-pill">
            <Sparkles aria-hidden="true" />
            <span>{isSending ? "Thinking" : "Ready"}</span>
          </div>
        </header>

        <div className="content-grid">
          <section className="chat-panel" aria-label="Chat">
            <div className="chat-toolbar">
              <div>
                <strong>Assistant Chat</strong>
                <span>{messages.length} messages</span>
              </div>
            </div>
            <div className="chat-log">
              {messages.map((message) => (
                <article className={`message ${message.role}`} key={message.id}>
                  <span>{message.role === "assistant" ? "Assistant" : name}</span>
                  <FormattedMessage content={message.content} />
                </article>
              ))}
              {isSending ? (
                <article className="message assistant loading-message" aria-live="polite">
                  <span>Assistant</span>
                  <div className="typing-loader" aria-label="Assistant is preparing an answer">
                    <i />
                    <i />
                    <i />
                  </div>
                </article>
              ) : null}
            </div>

            <div className="prompt-row">
              {promptIdeas.map((idea) => (
                <button key={idea} onClick={() => setInput(idea)} type="button">
                  {idea}
                </button>
              ))}
            </div>

            <form className="composer" onSubmit={sendMessage}>
              <input
                aria-label="Message"
                value={input}
                onChange={(event) => setInput(event.target.value)}
                disabled={isSending}
                placeholder="Ask for dinner ideas, weekly menu, allergy-safe meals..."
              />
              <button className="send-button" type="submit" aria-label="Send message" disabled={isSending}>
                {isSending ? <Loader2 className="spin" aria-hidden="true" /> : <Send aria-hidden="true" />}
              </button>
            </form>
          </section>

          <aside className="rag-panel">
            <div className="rag-header">
              <div className="section-title">
                <Search aria-hidden="true" />
                <h2>RAG Menu Matches</h2>
              </div>
              <span>{matchedMenus.length} found</span>
            </div>
            <div className="menu-list">
              {matchedMenus.length === 0 ? (
                <div className="empty-state">
                  Ask a question to see the chunks retrieved from your uploaded recipe/menu PDF.
                </div>
              ) : null}
              {matchedMenus.map((menu) => (
                <div className="menu-item" key={menu.id}>
                  <MessageSquareText aria-hidden="true" />
                  <div>
                    <strong>{menu.title}</strong>
                    <em>{menu.source === "uploaded-pdf" ? "Uploaded PDF" : "Demo data"}</em>
                    {menu.priceHints && menu.priceHints.length > 0 ? (
                      <small>Price: {menu.priceHints.join(", ")}</small>
                    ) : null}
                    <p>{menu.content.slice(0, 160)}</p>
                  </div>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </section>
    </main>
  );
}
