import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";

export type MenuDocument = {
  id: string;
  title: string;
  content: string;
};

export type MenuMatch = {
  id: string;
  title: string;
  content: string;
  score: number;
  priceHints?: string[];
  source?: "demo" | "uploaded-pdf";
};

const demoMenus: MenuDocument[] = [
  {
    id: "paneer-rice-bowl",
    title: "Paneer Rice Bowl",
    content: "Paneer rice bowl with cucumber salad. Vegetarian, protein rich, medium budget, mild spice."
  },
  {
    id: "egg-fried-rice",
    title: "Egg Fried Rice",
    content: "Egg fried rice with tomato chutney. Quick dinner, low cost, uses rice, eggs, tomato, onion."
  },
  {
    id: "dal-khichdi",
    title: "Vegetable Dal Khichdi",
    content: "Vegetable dal khichdi. Soft, comforting, vegetarian, budget friendly, good for low spice meals."
  }
];

export async function splitMenuDocuments(documents: MenuDocument[] = demoMenus) {
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 320,
    chunkOverlap: 40
  });

  return splitter.createDocuments(
    documents.map((document) => document.content),
    documents.map((document) => ({
      id: document.id,
      title: document.title
    }))
  );
}

export async function searchMenus(query: string, documents: MenuDocument[] = demoMenus): Promise<MenuMatch[]> {
  const normalizedQuery = query.toLowerCase();
  const queryWords = new Set(normalizedQuery.split(/\W+/).filter(Boolean));

  return documents
    .map((document) => {
      const searchableText = `${document.title} ${document.content}`.toLowerCase();
      const score = [...queryWords].reduce((total, word) => {
        return searchableText.includes(word) ? total + 1 : total;
      }, 0);

      return {
        ...document,
        score,
        source: "demo" as const
      };
    })
    .filter((match) => match.score > 0)
    .sort((first, second) => second.score - first.score)
    .slice(0, 3);
}

export const ragNotes = {
  localVectorDb: "ChromaDB",
  nextStep: "Replace searchMenus with Chroma vector search after you choose an embedding model."
};
