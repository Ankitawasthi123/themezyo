import { NextResponse } from "next/server";
import { isChromaConnectionError, listUploadedMenuChunks } from "@/lib/vector/chroma";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const limit = Number(url.searchParams.get("limit") ?? 20);

  try {
    const data = await listUploadedMenuChunks(Number.isFinite(limit) ? limit : 20);

    return NextResponse.json(data);
  } catch (error) {
    if (isChromaConnectionError(error)) {
      return NextResponse.json({ error: "ChromaDB is not running." }, { status: 503 });
    }

    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Could not read ChromaDB chunks." },
      { status: 500 }
    );
  }
}
