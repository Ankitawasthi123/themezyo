import { NextResponse } from "next/server";
import pdfParse from "pdf-parse/lib/pdf-parse.js";
import { RecursiveCharacterTextSplitter } from "@langchain/textsplitters";
import { isChromaConnectionError, storePdfChunks } from "@/lib/vector/chroma";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "PDF file is required." }, { status: 400 });
  }

  if (!file.name.toLowerCase().endsWith(".pdf") && file.type !== "application/pdf") {
    return NextResponse.json({ error: "Only PDF uploads are supported." }, { status: 400 });
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const result = await pdfParse(buffer);

    const text = result.text.trim();

    if (!text) {
      return NextResponse.json({ error: "No text could be extracted from this PDF." }, { status: 400 });
    }

    const splitter = new RecursiveCharacterTextSplitter({
      chunkSize: 700,
      chunkOverlap: 120
    });
    const documents = await splitter.createDocuments([text], [{ source: file.name, type: "pdf" }]);
    const uploadId = `${Date.now()}-${sanitizeId(file.name)}`;
    const chunks = documents.map((document, index) => ({
      id: `${uploadId}-${index}`,
      content: document.pageContent,
      metadata: {
        source: file.name,
        chunkIndex: index,
        type: "pdf" as const
      }
    }));
    const stored = await storePdfChunks(chunks);

    return NextResponse.json({
      fileName: file.name,
      extractedCharacters: text.length,
      ...stored
    });
  } catch (error) {
    if (isChromaConnectionError(error)) {
      return NextResponse.json(
        {
          error: "ChromaDB is not running. Start it with: chroma run --path ./chroma-data"
        },
        { status: 503 }
      );
    }

    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : "PDF upload failed."
      },
      { status: 500 }
    );
  }
}

function sanitizeId(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
