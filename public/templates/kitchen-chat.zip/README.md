# Kitchen Chat

A starter Next.js app for a personalized kitchen/menu chatbot with room for RAG, auth, menu ingestion, and chat history.

## Start

```bash
npm install
npm run dev
```

## Suggested Free Auth Options

- Auth.js / NextAuth with Credentials: good for a fully self-hosted MVP.
- Firebase Auth: generous free tier and simple Google/email login.
- Clerk: excellent DX with a free tier, but not fully self-hosted.
- Supabase Auth: still a strong option if you later use Supabase Postgres/pgvector.

This starter includes Auth.js / NextAuth with a local Credentials provider stub. It accepts any email with a password of at least 6 characters for local MVP testing. Replace it with a real users table before production.

Add this to `.env`:

```bash
AUTH_SECRET="replace-with-a-random-secret"
GOOGLE_API_KEY="replace-with-your-llm-api-key"
GOOGLE_PROJECT_ID="replace-with-your-google-project-id"
GOOGLE_PROJECT_NUMBER="replace-with-your-google-project-number"
LLM_MODEL="gemini-3.6-flash"
CHROMA_URL="http://localhost:8000"
```

For local work, prefer `.env.local` so secrets stay out of source control.

## RAG / LangChain

Installed packages:

- `langchain`
- `@langchain/core`
- `@langchain/textsplitters`
- `@langchain/community`
- `chromadb`

Starter files:

- `src/lib/rag/menu-rag.ts`
- `src/app/api/rag/route.ts`

Test the local RAG placeholder after starting the dev server:

```bash
curl -X POST http://localhost:3000/api/rag \
  -H "Content-Type: application/json" \
  -d "{\"query\":\"vegetarian low spice rice\",\"userProfile\":\"Vegetarian, low spice, budget friendly\"}"
```

## PDF Upload To ChromaDB

Start Chroma locally before uploading a PDF:

```bash
chroma run --path ./chroma-data
```

Then start the app and use the PDF button in the header. Uploaded PDFs are split into chunks, embedded with a free local hash embedding, and stored in the `kitchen_menu_chunks` Chroma collection.
