const DEFAULT_DIMENSIONS = 384;

export function createHashEmbedding(text: string, dimensions = DEFAULT_DIMENSIONS) {
  const vector = new Array<number>(dimensions).fill(0);
  const tokens = text.toLowerCase().match(/[a-z0-9]+/g) ?? [];

  for (const token of tokens) {
    const hash = hashToken(token);
    const index = Math.abs(hash) % dimensions;
    vector[index] += hash > 0 ? 1 : -1;
  }

  const magnitude = Math.sqrt(vector.reduce((total, value) => total + value * value, 0)) || 1;

  return vector.map((value) => value / magnitude);
}

function hashToken(token: string) {
  let hash = 2166136261;

  for (let index = 0; index < token.length; index += 1) {
    hash ^= token.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }

  return hash | 0;
}
