import { getLlmConfig } from "@/lib/llm/config";
import { formatPriceHints } from "@/lib/rag/price-hints";
import type { MenuMatch } from "@/lib/rag/menu-rag";

type GeminiResponse = {
  candidates?: Array<{
    content?: {
      parts?: Array<{
        text?: string;
      }>;
    };
  }>;
  error?: {
    message?: string;
  };
};

type GroqResponse = {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
  error?: {
    message?: string;
  };
};

export type GenerateKitchenAnswerInput = {
  query: string;
  userProfile?: string;
  matches: MenuMatch[];
};

export async function generateKitchenAnswer({ query, userProfile, matches }: GenerateKitchenAnswerInput) {
  const config = getLlmConfig();

  if (config.groqApiKey) {
    const groqCompletion = await generateGroqAnswer({
      apiKey: config.groqApiKey,
      model: config.groqModel,
      query,
      userProfile,
      matches
    });

    if (groqCompletion) {
      return groqCompletion;
    }
  }

  if (config.geminiApiKey) {
    const geminiCompletion = await generateGeminiAnswer({
      apiKey: config.geminiApiKey,
      model: config.geminiModel,
      query,
      userProfile,
      matches
    });

    if (geminiCompletion) {
      return geminiCompletion;
    }
  }

  console.warn("[llm] Missing GROQ_API_KEY, GOOGLE_API_KEY, or GEMINI_API_KEY. Using fallback answer.");

  return {
    answer: buildFallbackAnswer(query, userProfile, matches),
    model: config.model,
    provider: "fallback"
  };
}

async function generateGroqAnswer({
  apiKey,
  model,
  query,
  userProfile,
  matches
}: GenerateKitchenAnswerInput & { apiKey: string; model: string }) {
  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      messages: [
        {
          role: "user",
          content: buildKitchenPrompt(query, userProfile, matches)
        }
      ],
      temperature: 0.35,
      max_tokens: 700
    })
  });

  const payload = (await response.json().catch(() => ({}))) as GroqResponse;

  if (!response.ok) {
    console.warn("[llm/groq] Groq request failed. Trying next provider or fallback.", {
      status: response.status,
      model,
      message: payload.error?.message ?? "Groq request failed."
    });

    return null;
  }

  const answer = payload.choices?.[0]?.message?.content?.trim();

  return {
    answer: answer || buildFallbackAnswer(query, userProfile, matches),
    model,
    provider: "groq"
  };
}

async function generateGeminiAnswer({
  apiKey,
  model,
  query,
  userProfile,
  matches
}: GenerateKitchenAnswerInput & { apiKey: string; model: string }) {
  const modelPath = model.startsWith("models/") ? model : `models/${model}`;
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/${modelPath}:generateContent`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey
    },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts: [
            {
              text: buildKitchenPrompt(query, userProfile, matches)
            }
          ]
        }
      ],
      generationConfig: {
        temperature: 0.4,
        maxOutputTokens: 500
      }
    })
  });

  const payload = (await response.json().catch(() => ({}))) as GeminiResponse;

  if (!response.ok) {
    const message = payload.error?.message ?? "Gemini request failed.";

    if (response.status === 429 || message.toLowerCase().includes("quota")) {
      console.warn("[llm/gemini] Gemini quota/rate limit. Trying next provider or fallback.", {
        status: response.status,
        model
      });

      return null;
    }

    throw new Error(message);
  }

  const answer = payload.candidates?.[0]?.content?.parts?.map((part) => part.text).join("").trim();

  return {
    answer: answer || buildFallbackAnswer(query, userProfile, matches),
    model,
    provider: "gemini"
  };
}

function buildKitchenPrompt(query: string, userProfile: string | undefined, matches: MenuMatch[]) {
  const menuContext =
    matches.length > 0
      ? matches
          .map((match, index) => {
            const prices = match.priceHints?.length ? `\nPrice hints found: ${match.priceHints.join(", ")}` : "";

            return `${index + 1}. ${repairPdfText(match.title)}:\n${repairPdfText(match.content)}${prices}`;
          })
          .join("\n")
      : "No menu matches were found.";
  const priceContext = formatPriceHints(matches) || "No clear prices found in retrieved context.";

  return `You are Kitchen Chat, a practical kitchen/menu assistant.

User profile:
${userProfile || "No profile provided."}

Relevant menu context:
${menuContext}

Detected price hints:
${priceContext}

User request:
${query}

Answer rules:
- Do not say hello, welcome, or introduce yourself.
- Start directly with the recommendation.
- Retrieved PDF text may have broken words, odd line breaks, and OCR spacing issues. Use intelligent inference to repair obvious words and formatting before answering.
- Do not copy messy extracted PDF text directly into the final answer.
- If relevant uploaded menu context contains Ingredients and Method of Preparation, answer from that context first.
- If no retrieved context matches the user's main ingredients, then make a simple recipe using the user's ingredients.
- Do not recommend a retrieved menu item that ignores the user's main ingredients.
- If recipe/menu item names and prices are present in the context, return both.
- Only attach a price when it belongs to the same retrieved item or recipe. If the price belongs to another menu/PDF item, do not reuse it for the answer.
- Prefer this shape when price is available: Item: <name> | Price: <price> | Why: <short reason>.
- For recipes, use this shape: Item: <name> | Price: <price or not found> | Prep time: <time> | Cook time: <time> | Servings: <count> | Ingredients: <clean comma-separated list> | Method: <numbered steps> | Serving suggestion: <short idea> | Notes: <storage, spice, budget, or substitution note>.
- Keep the answer concise.
- Use natural plain text. Avoid markdown unless emphasizing a menu item name.
- Use only the menu context when recommending exact menu items.
- Do not invent prices. If price is not found, say "Price not found in uploaded menu."
- Mention allergy or medical safety uncertainty only if the user asks about health or allergens.`;
}

function buildFallbackAnswer(query: string, userProfile: string | undefined, matches: MenuMatch[]) {
  const wantsPrice = /\b(price|cost|rate|rs|inr|₹)\b/i.test(query);
  const wantsRecipe = /\b(recipe|cook|make|prepare|share)\b/i.test(query);
  const ingredients = extractIngredients(query);

  if (wantsRecipe) {
    const ragRecipe = findRagRecipeMatch(query, matches);

    if (ragRecipe) {
      return buildRagRecipeAnswer(ragRecipe);
    }
  }

  if (wantsRecipe && ingredients.length > 0) {
    return buildIngredientRecipe(ingredients);
  }

  if (wantsPrice) {
    const pricedMatches = matches.filter((match) => match.priceHints && match.priceHints.length > 0).slice(0, 5);

    if (pricedMatches.length > 0) {
      return pricedMatches.map((match) => `${repairPdfText(match.title)}: ${match.priceHints?.join(", ")}`).join("\n");
    }
  }

  const bestMatch = findRelevantMatch(query, matches);

  if (!bestMatch) {
    return `I could not find a strong menu match for "${query}". Try adding more menu data or ask for a recipe using your available ingredients.`;
  }

  const profileText = userProfile ? ` for your profile (${userProfile})` : "";
  const priceText = bestMatch.priceHints?.length ? ` Price: ${bestMatch.priceHints.join(", ")}.` : "";

  return `Best match${profileText}: ${repairPdfText(bestMatch.title)}.${priceText} ${repairPdfText(bestMatch.content)}`;
}

function findRelevantMatch(query: string, matches: MenuMatch[]) {
  const importantWords = getImportantWords(query);

  return matches.find((match) => {
    const searchableText = `${match.title} ${match.content}`.toLowerCase();
    const hits = importantWords.filter((word) => searchableText.includes(word)).length;

    return hits >= Math.min(2, importantWords.length);
  });
}

function findRagRecipeMatch(query: string, matches: MenuMatch[]) {
  const importantWords = getImportantWords(query);

  return matches
    .map((match) => {
      const text = `${match.id} ${match.title} ${match.content}`.toLowerCase();
      const isUploadedRecipe = (text.includes(".pdf") || text.includes("uploaded pdf")) && text.includes("method of preparation");
      const hits = importantWords.filter((word) => text.includes(word)).length;

      return {
        match,
        score: isUploadedRecipe ? hits * 10 + match.score : 0,
        hits
      };
    })
    .filter((candidate) => candidate.hits > 0 && candidate.score > 0)
    .sort((first, second) => second.score - first.score)[0]?.match;
}

function getRagRecipeHits(query: string, match: MenuMatch) {
  const importantWords = getImportantWords(query);
  const text = `${match.id} ${match.title} ${match.content}`.toLowerCase();

  return importantWords.filter((word) => text.includes(word)).length;
}

function buildRagRecipeAnswer(match: MenuMatch) {
  const title = inferRecipeTitleFromContent(match.content) || cleanAnswerText(match.title.replace(/\.pdf chunk \d+/i, "").trim()) || "Uploaded recipe";
  const price = match.priceHints?.length ? `Price: ${match.priceHints.join(", ")}\n` : "";
  const ingredients = extractSection(match.content, "Ingredients", ["DEVELOPED BY", "PRIMARY SCHOOL", "SECONDARY SCHOOL", "RECIPE BOOK", "Nutritional Information"]);
  const method = extractSection(match.content, "Method of Preparation", ["Ingredients", "DEVELOPED BY", "Nutritional Information", "Target Group"]);

  if (!ingredients && !method) {
    return `${repairPdfText(title)}\n${price}${repairPdfText(match.content).slice(0, 700)}`;
  }

  return `${repairPdfText(title)}\n${price}${ingredients ? `Ingredients: ${repairPdfText(ingredients)}\n` : ""}${method ? `Method: ${repairPdfText(method)}` : ""}`.trim();
}

function inferRecipeTitleFromContent(content: string) {
  const rejected = /^(recipe book|target group and|benefits|ingredients|method of preparation|developed by|north india recipes|east in dia|recipes)$/i;
  const lines = content
    .split(/\r?\n/)
    .map(cleanAnswerText)
    .filter((line) => line.length > 2)
    .filter((line) => !/^\d+$/.test(line))
    .filter((line) => !rejected.test(line));

  return lines.find((line) => /[a-z]/i.test(line) && !line.includes("..")) ?? "";
}

function extractSection(content: string, startLabel: string, endLabels: string[]) {
  const normalizedContent = cleanAnswerText(content);
  const startIndex = normalizedContent.toLowerCase().indexOf(startLabel.toLowerCase());

  if (startIndex === -1) {
    return "";
  }

  const afterStart = normalizedContent.slice(startIndex + startLabel.length).trim();
  const endIndexes = endLabels
    .map((label) => afterStart.toLowerCase().indexOf(label.toLowerCase()))
    .filter((index) => index > -1);
  const endIndex = endIndexes.length > 0 ? Math.min(...endIndexes) : Math.min(afterStart.length, 600);

  return afterStart.slice(0, endIndex).replace(/\s+/g, " ").trim().slice(0, 500);
}

function cleanAnswerText(value: string) {
  return value.replace(/\s+/g, " ").replace(/[Â�]/g, "").trim();
}

function repairPdfText(value: string) {
  return cleanAnswerText(value)
    .replace(/\bIn dia\b/gi, "India")
    .replace(/\bm ix\b/gi, "mix")
    .replace(/\bCh ildren\b/gi, "Children")
    .replace(/\bpr eservative\b/gi, "preservative")
    .replace(/\bWean ing\b/gi, "Weaning")
    .replace(/\bWhea t\b/gi, "Wheat")
    .replace(/\bGr am\b/gi, "Gram")
    .replace(/\s+([,.;:])/g, "$1")
    .replace(/([a-z])\s{2,}([a-z])/gi, "$1 $2")
    .trim();
}

function extractIngredients(query: string) {
  const ingredientWords = [
    "potato",
    "onion",
    "capsicum",
    "tomato",
    "maggi",
    "maggie",
    "magie",
    "noodles",
    "egg",
    "ege",
    "rice",
    "paneer",
    "dal",
    "chilli",
    "garlic",
    "ginger"
  ];
  const normalizedQuery = query.toLowerCase();

  return [...new Set(ingredientWords.filter((word) => normalizedQuery.includes(word)).map(normalizeIngredient))];
}

function normalizeIngredient(ingredient: string) {
  if (ingredient === "ege") {
    return "egg";
  }

  if (ingredient === "maggie" || ingredient === "magie") {
    return "maggi";
  }

  return ingredient;
}

function getImportantWords(query: string) {
  const stopWords = new Set(["i", "have", "the", "a", "an", "and", "with", "share", "recipe", "provide", "for", "me"]);

  return query
    .toLowerCase()
    .split(/\W+/)
    .map(normalizeIngredient)
    .filter((word) => word.length > 2 && !stopWords.has(word));
}

function buildIngredientRecipe(ingredients: string[]) {
  const ingredientList = ingredients.join(", ");

  if (ingredients.includes("maggi") && ingredients.includes("egg")) {
    return `Item: Egg Masala Maggi | Price: Price not found in uploaded menu | Prep time: 5 minutes | Cook time: 8 minutes | Servings: 1 to 2 | Ingredients: ${ingredientList}, oil, salt, mild spices, maggi masala, water | Method: 1. Chop the onion and tomato. 2. Saute onion and tomato with a little oil, salt, and mild spices. 3. Add maggi masala and water, then cook the noodles. 4. Scramble in the egg at the end and cook until set. | Serving suggestion: Serve hot as a quick snack or light dinner. | Notes: Keep spice low by using less masala or adding extra tomato.`;
  }

  if (ingredients.includes("potato") && ingredients.includes("capsicum")) {
    return `Item: Potato Onion Capsicum Stir-Fry | Price: Price not found in uploaded menu | Prep time: 10 minutes | Cook time: 15 minutes | Servings: 2 | Ingredients: ${ingredientList}, 1 tbsp oil, cumin seeds, turmeric, coriander powder, salt | Method: 1. Dice the potato, onion, and capsicum into even pieces. 2. Heat oil in a pan and add cumin seeds. 3. Add onion and saute until translucent. 4. Add potato, turmeric, coriander powder, salt, and a splash of water. 5. Cover and cook until the potato is almost tender. 6. Add capsicum and stir-fry for 3 to 4 minutes so it stays slightly crisp. | Serving suggestion: Serve with roti, dal, or plain rice. | Notes: For low spice, skip chili and keep the capsicum slightly crunchy.`;
  }

  return `Item: Simple Vegetable Stir-Fry | Price: Price not found in uploaded menu | Prep time: 10 minutes | Cook time: 12 minutes | Servings: 2 | Ingredients: ${ingredientList}, oil, salt, mild spices | Method: 1. Chop the ingredients evenly. 2. Saute onion first if available. 3. Add firm vegetables, salt, and mild spices. 4. Cook covered until tender. 5. Finish with tomato or a little water if needed. | Serving suggestion: Serve hot with roti or rice. | Notes: Adjust cooking time based on the hardest vegetable.`;
}
