export type LlmConfig = {
  apiKey?: string;
  groqApiKey?: string;
  groqModel: string;
  geminiApiKey?: string;
  geminiModel: string;
  model: string;
  projectId?: string;
  projectNumber?: string;
};

export function getLlmConfig(): LlmConfig {
  const groqModel = process.env.GROQ_MODEL ?? "openai/gpt-oss-20b";
  const geminiModel = process.env.GEMINI_MODEL ?? process.env.LLM_MODEL ?? "gemini-3.5-flash";

  return {
    apiKey: process.env.GROQ_API_KEY ?? process.env.GOOGLE_API_KEY ?? process.env.GEMINI_API_KEY,
    groqApiKey: process.env.GROQ_API_KEY,
    groqModel,
    geminiApiKey: process.env.GOOGLE_API_KEY ?? process.env.GEMINI_API_KEY,
    geminiModel,
    model: process.env.GROQ_API_KEY ? groqModel : geminiModel,
    projectId: process.env.GOOGLE_PROJECT_ID,
    projectNumber: process.env.GOOGLE_PROJECT_NUMBER
  };
}
