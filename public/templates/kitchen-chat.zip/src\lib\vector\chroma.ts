import { ChromaClient } from "chromadb";
import type { EmbeddingFunction } from "chromadb";
import type { MenuMatch } from "@/lib/rag/menu-rag";
import { addPriceHints } from "@/lib/rag/price-hints";
import { createHashEmbedding } from "@/lib/vector/hash-embedding";

const COLLECTION_NAME = "kitchen_menu_chunks";
const localEmbeddingFunction: EmbeddingFunction = {
  name: "local-hash-embedding",
  async generate(texts: string[]) {
    return texts.map((text) => createHashEmbedding(text));
  },
  async generateForQueries(texts: string[]) {
    return texts.map((text) => createHashEmbedding(text));
  }
};

type StoredChunk = {
  id: string;
  content: string;
  metadata: {
    source: string;
    chunkIndex: number;
    type: "pdf";
  };
};

export function getChromaClient() {
  const url = new URL(process.env.CHROMA_URL ?? "http://localhost:8000");

  return new ChromaClient({
    host: url.hostname,
    port: Number(url.port || (url.protocol === "https:" ? 443 : 8000)),
    ssl: url.protocol === "https:"
  });
}

export async function getMenuCollection() {
  const client = getChromaClient();

  return client.getOrCreateCollection({
    name: COLLECTION_NAME,
    embeddingFunction: localEmbeddingFunction
  });
}

export async function storePdfChunks(chunks: StoredChunk[]) {
  const collection = await getMenuCollection();

  await collection.add({
    ids: chunks.map((chunk) => chunk.id),
    documents: chunks.map((chunk) => chunk.content),
    embeddings: chunks.map((chunk) => createHashEmbedding(chunk.content)),
    metadatas: chunks.map((chunk) => ({
      source: chunk.metadata.source,
      chunkIndex: chunk.metadata.chunkIndex,
      type: chunk.metadata.type
    }))
  });

  return {
    collection: COLLECTION_NAME,
    chunksStored: chunks.length
  };
}

export async function searchUploadedMenuChunks(query: string, limit = 4): Promise<MenuMatch[]> {
  const collection = await getMenuCollection();
  const results = await collection.query({
    queryEmbeddings: [createHashEmbedding(query)],
    nResults: limit,
    include: ["documents", "metadatas", "distances"]
  });

  const documents = results.documents?.[0] ?? [];
  const metadatas = results.metadatas?.[0] ?? [];
  const distances = results.distances?.[0] ?? [];

  return documents
    .map((document, index) => {
      const metadata = metadatas[index] as { source?: string; chunkIndex?: number } | null;
      const source = metadata?.source ?? "Uploaded PDF";
      const chunkIndex = metadata?.chunkIndex ?? index;

      return addPriceHints({
        id: `${source}-${chunkIndex}`,
        title: `${source} chunk ${chunkIndex + 1}`,
        content: document ?? "",
        score: typeof distances[index] === "number" ? 1 / (1 + distances[index]) : 0,
        source: "uploaded-pdf"
      });
    })
    .filter((match) => match.content.trim().length > 0);
}

export async function findUploadedPriceChunks(limit = 8): Promise<MenuMatch[]> {
  const collection = await getMenuCollection();
  const results = await collection.get({
    limit: 500,
    include: ["documents", "metadatas"]
  });

  return results.ids
    .map((id, index) => {
      const document = results.documents?.[index] ?? "";
      const metadata = results.metadatas?.[index] as { source?: string; chunkIndex?: number } | null;
      const source = metadata?.source ?? "Uploaded PDF";
      const chunkIndex = metadata?.chunkIndex ?? index;
      const title = inferRecipeTitle(document, source, chunkIndex);

      return addPriceHints({
        id,
        title,
        content: document,
        score: document.toLowerCase().includes("cost") ? 2 : 1,
        source: "uploaded-pdf"
      });
    })
    .filter((match) => match.priceHints && match.priceHints.length > 0)
    .slice(0, limit);
}

function inferRecipeTitle(content: string, source: string, chunkIndex: number) {
  const lines = content
    .split(/\r?\n/)
    .map((line) => cleanTitleLine(line))
    .filter(Boolean);
  const nutritionalIndex = lines.findIndex((line) => /nutritional information\/100 grams/i.test(line));
  const titleBeforeNutrition = getTitleCandidate(lines.slice(Math.max(0, nutritionalIndex - 6), nutritionalIndex));
  const titleAfterNutrition = lines.slice(nutritionalIndex + 1).find(isLikelyRecipeTitle);

  if (nutritionalIndex > -1) {
    return titleBeforeNutrition ?? titleAfterNutrition ?? `${source} chunk ${chunkIndex + 1}`;
  }

  const shelfLifeIndex = lines.findIndex((line) => /^shelf life$/i.test(line));
  const titleBeforeShelfLife = getTitleCandidate(lines.slice(0, shelfLifeIndex > -1 ? shelfLifeIndex : Math.min(lines.length, 8)));

  return titleBeforeShelfLife ?? `${source} chunk ${chunkIndex + 1}`;
}

function cleanTitleLine(line: string) {
  return line.replace(/\s+/g, " ").replace(/\bm\s+ix\b/gi, "mix").trim();
}

function isLikelyRecipeTitle(line: string) {
  return (
    line.length > 2 &&
    !/^\d+$/.test(line) &&
    !/^rs\.?/i.test(line) &&
    !/\bcost\b/i.test(line) &&
    !/^(recipe book|east in dia|recipes|shelf life|cost|best before|one year from|the date of|manufacturing|target group and|benefits|ingredients|method of preparation)$/i.test(line) &&
    !/^(energy|protein|calcium|iron|carbohydrate|total fat|crude fibre|vitamin c|total mineral|nutritional information\/100 grams)$/i.test(line) &&
    !/^\d+(?:\.\d+)?(?:-\d+(?:\.\d+)?)?\s*(gm|mg|kcal|days?|weeks?|months?|year)/i.test(line)
  );
}

function getTitleCandidate(lines: string[]) {
  const candidates = lines.filter(isLikelyRecipeTitle);
  const last = candidates.at(-1);
  const previous = candidates.at(-2);

  if (last && /^\(.+\)$/.test(last) && previous) {
    return `${previous} ${last}`;
  }

  return last;
}

export async function listUploadedMenuChunks(limit = 20) {
  const collection = await getMenuCollection();
  const results = await collection.get({
    limit,
    include: ["documents", "metadatas"]
  });

  return {
    collection: COLLECTION_NAME,
    count: results.ids.length,
    chunks: results.ids.map((id, index) => ({
      id,
      document: results.documents?.[index] ?? "",
      metadata: results.metadatas?.[index] ?? null
    }))
  };
}

export function isChromaConnectionError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);

  return message.includes("fetch failed") || message.includes("ECONNREFUSED") || message.includes("connect");
}
